#!/bin/bash
java -jar Digital.jar "$1"